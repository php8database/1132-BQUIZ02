<?php
// 當表單提交時，插入新的文章
if (isset($_POST['add_news'])) {
    // 從表單獲取資料
    $title = $_POST['title'];
    $category = $_POST['category'];
    $content = $_POST['content'];

    // 準備資料陣列
    $data = [
        'title' => $title,
        'news' => $content,
        'type' => $category,
        'likes' => 0, // 預設為 0
        'sh' => 1     // 預設顯示
    ];

    // 使用DB類別插入資料
    $News->save($data);

    // 在所有HTML輸出之前使用 header() 進行重定向
    header("Location: admin.php?do=news");
    exit;  // 確保在重定向後停止執行後續程式碼
}
?>

<fieldset style='width:85%;margin:auto'>
    <legend>最新文章管理</legend>

    <!-- 新增文章按鈕，向左靠齊 -->
    <div class="ct" style="text-align:left; margin-bottom:20px;">
        <button type="button" id="addNewsButton" onclick="showAddForm()">新增文章</button>
    </div>

    <!-- 新增文章表單，初始隱藏 -->
    <div id="addNewsForm" style="display:none;">
        <form action="admin.php?do=news" method="post">
            <label for="title">文章標題：</label>
            <input type="text" id="title" name="title" required><br><br>

            <label for="category">文章分類：</label>
            <select id="category" name="category" required>
                <option value="1">健康新知</option>
                <option value="2">菸害防治</option>
                <option value="3">癌症防治</option>
                <option value="4">慢性病防治</option>
            </select><br><br>

            <label for="content">文章內容：</label><br>
            <textarea id="content" name="content" rows="5" cols="50" required></textarea><br><br>

            <button type="submit" name="add_news">新增</button>            
            <button type="reset">重置</button>
            <button type="button" onclick="cancelAdd()">取消</button>
        </form>
    </div>

    <!-- 文章列表 -->
    <table class="ct" style="width:100%">
        <tr>
            <th>編號</th>
            <th width="50%">標題</th>
            <th>顯示</th>
            <th>刪除</th>
        </tr>
        <?php
        $total = $News->count();
        $div = 3;
        $pages = ceil($total / $div);
        $now = $_GET['p'] ?? 1;
        $start = ($now - 1) * $div;

        $rows = $News->all("Limit $start, $div");
        foreach ($rows as $idx => $row):
        ?>
            <tr>
                <td><?=$start + $idx + 1;?></td>
                <td><?=$row['title'];?></td>
                <td>
                    <input type="checkbox" name="sh[]" value="<?=$row['id'];?>" <?=($row['sh'] == 1) ? "checked" : ""; ?>>
                </td>
                <td>
                    <input type="checkbox" name="del[]" value="<?=$row['id'];?>">
                </td>
            </tr>
            <input type="hidden" name="id[]" value="<?=$row['id'];?>">
        <?php endforeach; ?>
    </table>

    <!-- 分頁導航 -->
    <div id="pagination" class="ct">
        <?php
        if (($now - 1) > 0) {
            echo "<a href='?do=news&p=" . ($now - 1) . "'> &lt;</a>";
        }

        for ($i = 1; $i <= $pages; $i++) {
            $size = ($i == $now) ? "24px" : "16px";
            echo "<a href='?do=news&p=$i' style='font-size:$size'> $i </a>";
        }

        if (($now + 1) <= $pages) {
            echo "<a href='?do=news&p=" . ($now + 1) . "'> &gt;</a>";
        }
        ?>
    </div>

    <div class="ct">
        <button id="editButton" onclick="edit()">確定修改</button>
    </div>
</fieldset>

<script>
// 顯示新增文章表單
function showAddForm() {
    // 隱藏新增文章按鈕
    document.getElementById('addNewsButton').style.display = 'none';

    // 隱藏分頁導航
    document.getElementById('pagination').style.display = 'none';

    // 隱藏確定修改按鈕
    document.getElementById('editButton').style.display = 'none';

    // 變更legend的文字為 "新增文章"
    document.querySelector('legend').textContent = '新增文章';

    // 顯示新增文章表單
    document.getElementById('addNewsForm').style.display = 'block';
    // 隱藏文章列表
    document.querySelector('table').style.display = 'none';  
}

// 取消新增文章，返回文章列表
function cancelAdd() {
    // 恢復legend的文字為 "最新文章管理"
    document.querySelector('legend').textContent = '最新文章管理';

    // 顯示新增文章按鈕
    document.getElementById('addNewsButton').style.display = 'inline-block';

    // 顯示分頁導航
    document.getElementById('pagination').style.display = 'block';

    // 顯示確定修改按鈕
    document.getElementById('editButton').style.display = 'inline-block';

    // 隱藏新增文章表單
    document.getElementById('addNewsForm').style.display = 'none';
    // 顯示文章列表
    document.querySelector('table').style.display = 'block';  
    window.location.href = 'admin.php?do=news';  // 返回文章管理頁面
}

// 確定修改文章顯示狀態與刪除
function edit() {
    let ids = $("input[name='id[]']") // 獲取所有文章ID
                .map((idx, item) => $(item).val()).get();
    let del = $("input[name='del[]']:checked") // 獲取所有選中的刪除項
                .map((idx, item) => $(item).val()).get();
    let sh = $("input[name='sh[]']:checked") // 獲取所有選中的顯示項
                .map((idx, item) => $(item).val()).get();

    $.post("./api/edit_news.php", {ids, sh, del}, (res) => {
        location.reload(); // 重新加載頁面
    });
}
</script>
