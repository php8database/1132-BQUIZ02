<fieldset style="width:70%;margin:auto">
    <legend>新增問卷</legend>
    <table style="width:100%">
        <tr>
            <td class='clo'>問卷名稱</td>
            <td>
                <input type="text" name="subject" id="subject" style="width:80%">
            </td>
        </tr>
        <tr class='clo'>
            <td colspan='2'>
                <div id="options">
                    選項<input type="text" name="option[]" id=""  style="width:80%">
                    <button onclick="more()">更多</button>
                </div>
            </td>
        </tr>
    </table>
    <div class="ct">
        <button onclick="send()">新增</button>
        <button onclick="resetForm()">清空</button>
    </div>
</fieldset>

<script>
    function more(){
        let el=`<div>選項<input type="text" name="option[]" id="" style="width:80%"></div>`
        $("#options").before(el)
    }
    function send(){
        let subject=$("#subject").val()
        let options=$("input[name='option[]']").map((id,item)=>$(item).val()).get()

        $.post("./api/add_que.php",{subject,options},(res)=>{
            location.reload()
        })
    }
    function resetForm(){
        $("input[type='text']").val("")
    }
</script>

<fieldset style="width:70%;margin:auto">
    <legend>問卷列表</legend>
    <table style="width:100%; text-align:center">
        <tr>
            <td class='clo' style="width:50%">問卷名稱</td>
            <td class='clo' style="width:25%">投票數</td>
            <td class='clo' style="width:25%">開放</td>
        </tr>
        <?php 
        $rows = $Que->all(['main_id' => 0]); // 假設問卷的主題
        foreach ($rows as $row):
        ?>
        <tr>
            <td><?=$row['text'];?></td>
            <td><?=$row['vote'];?></td>
            <td>
                <!-- 這裡的開關可以用來控制 sh 欄位的值 -->
                <?php if ($row['sh'] == 1): ?>
                    <button onclick="toggleStatus(<?=$row['id'];?>, 0)">關閉</button>
                <?php else: ?>
                    <button onclick="toggleStatus(<?=$row['id'];?>, 1)">開放</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</fieldset>

<script>
    function toggleStatus(id, status) {
        // 向後台發送請求來更新問卷的顯示狀態
        $.post('./api/update_que_status.php', {id: id, sh: status}, function(response) {
            location.reload();  // 重新加載頁面以反映更改
        });
    }
</script>
