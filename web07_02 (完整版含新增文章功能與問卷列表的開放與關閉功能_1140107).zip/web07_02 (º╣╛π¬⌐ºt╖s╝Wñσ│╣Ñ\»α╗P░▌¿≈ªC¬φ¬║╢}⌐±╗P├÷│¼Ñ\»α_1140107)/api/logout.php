<?php 
include_once "db.php";

unset($_SESSION['user']);