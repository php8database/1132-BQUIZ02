<?php
include_once "db.php";

$id = $_POST['id'];
$sh = $_POST['sh'];

// 更新問卷的顯示狀態
$Que->save(['id' => $id, 'sh' => $sh]);

echo "成功更新顯示狀態";
?>
